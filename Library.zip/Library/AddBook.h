#pragma once

namespace Library {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Data::SqlClient;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Home
	/// </summary>
	public ref class AddBook : public System::Windows::Forms::Form
	{
	public:
		AddBook(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~AddBook()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ save;
	protected:
	private: System::Windows::Forms::TextBox^ PublicationTB;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::TextBox^ AuthorTB;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::TextBox^ TitleTB;
	private: System::Windows::Forms::Label^ label1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->save = (gcnew System::Windows::Forms::Button());
			this->PublicationTB = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->AuthorTB = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->TitleTB = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// save
			// 
			this->save->Anchor = System::Windows::Forms::AnchorStyles::None;
			this->save->BackColor = System::Drawing::Color::MediumAquamarine;
			this->save->Font = (gcnew System::Drawing::Font(L"Times New Roman", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->save->Location = System::Drawing::Point(200, 269);
			this->save->Name = L"save";
			this->save->Size = System::Drawing::Size(239, 39);
			this->save->TabIndex = 42;
			this->save->Text = L"Save";
			this->save->UseVisualStyleBackColor = false;
			this->save->Click += gcnew System::EventHandler(this, &AddBook::save_Click);
			// 
			// PublicationTB
			// 
			this->PublicationTB->Anchor = System::Windows::Forms::AnchorStyles::None;
			this->PublicationTB->Location = System::Drawing::Point(336, 189);
			this->PublicationTB->Name = L"PublicationTB";
			this->PublicationTB->Size = System::Drawing::Size(120, 26);
			this->PublicationTB->TabIndex = 37;
			// 
			// label3
			// 
			this->label3->Anchor = System::Windows::Forms::AnchorStyles::None;
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(162, 189);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(120, 20);
			this->label3->TabIndex = 36;
			this->label3->Text = L"Publication year";
			// 
			// AuthorTB
			// 
			this->AuthorTB->Anchor = System::Windows::Forms::AnchorStyles::None;
			this->AuthorTB->Location = System::Drawing::Point(336, 139);
			this->AuthorTB->Name = L"AuthorTB";
			this->AuthorTB->Size = System::Drawing::Size(120, 26);
			this->AuthorTB->TabIndex = 35;
			// 
			// label2
			// 
			this->label2->Anchor = System::Windows::Forms::AnchorStyles::None;
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(162, 139);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(57, 20);
			this->label2->TabIndex = 34;
			this->label2->Text = L"Author";
			// 
			// TitleTB
			// 
			this->TitleTB->Anchor = System::Windows::Forms::AnchorStyles::None;
			this->TitleTB->Location = System::Drawing::Point(336, 93);
			this->TitleTB->Name = L"TitleTB";
			this->TitleTB->Size = System::Drawing::Size(120, 26);
			this->TitleTB->TabIndex = 33;
			// 
			// label1
			// 
			this->label1->Anchor = System::Windows::Forms::AnchorStyles::None;
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(162, 96);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(38, 20);
			this->label1->TabIndex = 32;
			this->label1->Text = L"Title";
			// 
			// AddBook
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(9, 20);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(880, 410);
			this->Controls->Add(this->save);
			this->Controls->Add(this->PublicationTB);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->AuthorTB);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->TitleTB);
			this->Controls->Add(this->label1);
			this->Name = L"AddBook";
			this->Text = L"AddBook";
			this->Load += gcnew System::EventHandler(this, &AddBook::AddBook_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void AddBook_Load(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void save_Click(System::Object^ sender, System::EventArgs^ e) {
		try {
			String^ connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=LibraryDB;Integrated Security=True";

			// Check if all fields are filled
			if (String::IsNullOrWhiteSpace(TitleTB->Text) || String::IsNullOrWhiteSpace(AuthorTB->Text) || String::IsNullOrWhiteSpace(PublicationTB->Text)) {
				MessageBox::Show("Please fill in all fields.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
				return;
			}

			// Validate PublicationTB length
			if (PublicationTB->Text->Length < 4) {
				MessageBox::Show("Publication year should be 4 characters.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
				return;
			}

			// Create a SqlConnection
			SqlConnection^ connection = gcnew SqlConnection(connectionString);

			// Open the connection
			connection->Open();

			// Create a SqlCommand for the stored procedure
			SqlCommand^ command = gcnew SqlCommand("usp_AddBook", connection);
			command->CommandType = CommandType::StoredProcedure;

			// Add parameters
			command->Parameters->AddWithValue("@Title", TitleTB->Text);
			command->Parameters->AddWithValue("@Author", AuthorTB->Text);
			command->Parameters->AddWithValue("@PublicationYear", PublicationTB->Text);

			// Execute the stored procedure
			command->ExecuteNonQuery();

			MessageBox::Show("Book added successfully.", "Success", MessageBoxButtons::OK, MessageBoxIcon::Information);

			// Clear the textboxes after successful addition
			TitleTB->Text = "";
			AuthorTB->Text = "";
			PublicationTB->Text = "";
		}
		catch (Exception^ ex) {
			// Handle any exceptions
			MessageBox::Show("Error: " + ex->Message, "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
	}

};
}
