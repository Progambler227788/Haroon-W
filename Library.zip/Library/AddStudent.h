#pragma once

namespace Library {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Data::SqlClient;
	/// <summary>
	/// Summary for AddStudent
	/// </summary>
	public ref class AddStudent : public System::Windows::Forms::Form
	{
	public:
		AddStudent(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~AddStudent()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ save;
	protected:
	private: System::Windows::Forms::TextBox^ EmailTB;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::TextBox^ AgeTB;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::TextBox^ NameTB;
	private: System::Windows::Forms::Label^ label1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->save = (gcnew System::Windows::Forms::Button());
			this->EmailTB = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->AgeTB = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->NameTB = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// save
			// 
			this->save->Anchor = System::Windows::Forms::AnchorStyles::None;
			this->save->BackColor = System::Drawing::Color::MediumAquamarine;
			this->save->Font = (gcnew System::Drawing::Font(L"Times New Roman", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->save->Location = System::Drawing::Point(216, 271);
			this->save->Name = L"save";
			this->save->Size = System::Drawing::Size(239, 39);
			this->save->TabIndex = 49;
			this->save->Text = L"Save";
			this->save->UseVisualStyleBackColor = false;
			this->save->Click += gcnew System::EventHandler(this, &AddStudent::save_Click);
			// 
			// EmailTB
			// 
			this->EmailTB->Anchor = System::Windows::Forms::AnchorStyles::None;
			this->EmailTB->Location = System::Drawing::Point(352, 191);
			this->EmailTB->Name = L"EmailTB";
			this->EmailTB->Size = System::Drawing::Size(120, 26);
			this->EmailTB->TabIndex = 48;
			// 
			// label3
			// 
			this->label3->Anchor = System::Windows::Forms::AnchorStyles::None;
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(178, 191);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(48, 20);
			this->label3->TabIndex = 47;
			this->label3->Text = L"Email";
			// 
			// AgeTB
			// 
			this->AgeTB->Anchor = System::Windows::Forms::AnchorStyles::None;
			this->AgeTB->Location = System::Drawing::Point(352, 141);
			this->AgeTB->Name = L"AgeTB";
			this->AgeTB->Size = System::Drawing::Size(120, 26);
			this->AgeTB->TabIndex = 46;
			// 
			// label2
			// 
			this->label2->Anchor = System::Windows::Forms::AnchorStyles::None;
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(178, 141);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(38, 20);
			this->label2->TabIndex = 45;
			this->label2->Text = L"Age";
			// 
			// NameTB
			// 
			this->NameTB->Anchor = System::Windows::Forms::AnchorStyles::None;
			this->NameTB->Location = System::Drawing::Point(352, 95);
			this->NameTB->Name = L"NameTB";
			this->NameTB->Size = System::Drawing::Size(120, 26);
			this->NameTB->TabIndex = 44;
			// 
			// label1
			// 
			this->label1->Anchor = System::Windows::Forms::AnchorStyles::None;
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(178, 98);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(51, 20);
			this->label1->TabIndex = 43;
			this->label1->Text = L"Name";
			// 
			// AddStudent
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(9, 20);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(995, 412);
			this->Controls->Add(this->save);
			this->Controls->Add(this->EmailTB);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->AgeTB);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->NameTB);
			this->Controls->Add(this->label1);
			this->Name = L"AddStudent";
			this->Text = L"AddStudent";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void save_Click(System::Object^ sender, System::EventArgs^ e) {
		String^ connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=LibraryDB;Integrated Security=True";

		// Check if all fields are filled
		if (String::IsNullOrWhiteSpace(NameTB->Text) || String::IsNullOrWhiteSpace(AgeTB->Text) || String::IsNullOrWhiteSpace(EmailTB->Text)) {
			MessageBox::Show("Please fill in all fields.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
			return;
		}

		// Validate age
		int age;
		if (!Int32::TryParse(AgeTB->Text, age) || age <= 0) {
			MessageBox::Show("Please enter a valid age.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
			return;
		}

		// Validate email
		System::Net::Mail::MailAddress^ emailAddress;
		try {
			emailAddress = gcnew System::Net::Mail::MailAddress(EmailTB->Text);
		}
		catch (FormatException^) {
			MessageBox::Show("Please enter a valid email address.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
			return;
		}
		try {
			

			// Check if all fields are filled
			if (String::IsNullOrWhiteSpace(NameTB->Text) || String::IsNullOrWhiteSpace(AgeTB->Text) || String::IsNullOrWhiteSpace(EmailTB->Text)) {
				MessageBox::Show("Please fill in all fields.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
				return;
			}

	

			// Create a SqlConnection
			SqlConnection^ connection = gcnew SqlConnection(connectionString);

			// Open the connection
			connection->Open();

			// Create a SqlCommand for the stored procedure
			SqlCommand^ command = gcnew SqlCommand("usp_AddStudent", connection);
			command->CommandType = CommandType::StoredProcedure;

			// Add parameters
			command->Parameters->AddWithValue("@name", NameTB->Text);
			command->Parameters->AddWithValue("@age", AgeTB->Text);
			command->Parameters->AddWithValue("@email", EmailTB->Text);

			// Execute the stored procedure
			command->ExecuteNonQuery();

			MessageBox::Show("Student added successfully.", "Success", MessageBoxButtons::OK, MessageBoxIcon::Information);

			// Clear the textboxes after successful addition
			NameTB->Text = "";
			AgeTB->Text = "";
			EmailTB->Text = "";
		}
		catch (Exception^ ex) {
			// Handle any exceptions
			MessageBox::Show("Error: " + ex->Message, "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
	}
};
}
