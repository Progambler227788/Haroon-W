
CREATE PROCEDURE getStudents
AS
BEGIN
    SELECT * FROM StudentData;
END;