# Bank-Management-System
[![SMS Created](https://img.shields.io/badge/Created-February%202019-blue.svg)](#)
[![SMS version](https://img.shields.io/badge/ConsoleApplication-orange.svg)](#)
[![SMS Licence](https://img.shields.io/badge/Language-Csharp-brightgreen.svg)](#)

Here is a project we developed as ConsoleApp in C# bank management system ; it is complete and totally error-free. This project is focused on customer account services in bank, so it is named “Customer Account Bank Management System”. 

Here, you can create a new account, show account information, Deposit from account, Withdraw from account, Show all account with id, Clear screen and Exit.


Overall, with this project, you can perform banking activities like in a REAL bank. Bank management mini project in C# is a console application. It is compiled in Visual Studio 2017.
