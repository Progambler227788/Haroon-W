CREATE PROCEDURE usp_GetStudents
AS
BEGIN
    SELECT * FROM Student;
END;