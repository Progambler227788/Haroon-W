CREATE PROCEDURE usp_ClearStudents
AS
BEGIN
    DELETE FROM Student;
END;