README File

Click on View, Click on Server Explorer, Right click on Data Connection, Add Data Connection with below data
Server Name : (localdb)\MSSQLLocalDB
Database Name: LibraryDB

Right click on Tables, select new query.

Execute all queries one by one. Book Table Create and Student Table Create at first. Then, execute procedure files.

