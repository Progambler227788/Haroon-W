CREATE PROCEDURE getLecturers
AS
BEGIN
    SELECT * FROM LecturerData;
END;