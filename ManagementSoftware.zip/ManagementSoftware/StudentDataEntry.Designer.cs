﻿namespace ManagementSoftware
{
    partial class StudentDataEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.NameTB = new System.Windows.Forms.TextBox();
            this.AddressTB = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.CountryTB = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.AgeTB = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.PhoneTB = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.EmailTB = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.StudentNumberTB = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.save = new System.Windows.Forms.Button();
            this.home = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(129, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            // 
            // NameTB
            // 
            this.NameTB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.NameTB.Location = new System.Drawing.Point(274, 76);
            this.NameTB.Name = "NameTB";
            this.NameTB.Size = new System.Drawing.Size(120, 26);
            this.NameTB.TabIndex = 1;
            // 
            // AddressTB
            // 
            this.AddressTB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AddressTB.Location = new System.Drawing.Point(274, 119);
            this.AddressTB.Name = "AddressTB";
            this.AddressTB.Size = new System.Drawing.Size(120, 26);
            this.AddressTB.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(129, 119);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Address";
            // 
            // CountryTB
            // 
            this.CountryTB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.CountryTB.Location = new System.Drawing.Point(274, 169);
            this.CountryTB.Name = "CountryTB";
            this.CountryTB.Size = new System.Drawing.Size(120, 26);
            this.CountryTB.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(129, 169);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Country";
            // 
            // AgeTB
            // 
            this.AgeTB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AgeTB.Location = new System.Drawing.Point(274, 217);
            this.AgeTB.Name = "AgeTB";
            this.AgeTB.Size = new System.Drawing.Size(120, 26);
            this.AgeTB.TabIndex = 7;
            this.AgeTB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.AgeTB_KeyPress);
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(129, 217);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Age";
            // 
            // PhoneTB
            // 
            this.PhoneTB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PhoneTB.Location = new System.Drawing.Point(274, 265);
            this.PhoneTB.Name = "PhoneTB";
            this.PhoneTB.Size = new System.Drawing.Size(120, 26);
            this.PhoneTB.TabIndex = 9;
            this.PhoneTB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PhoneTB_KeyPress);
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(129, 271);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Phone";
            // 
            // EmailTB
            // 
            this.EmailTB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EmailTB.Location = new System.Drawing.Point(274, 317);
            this.EmailTB.Name = "EmailTB";
            this.EmailTB.Size = new System.Drawing.Size(120, 26);
            this.EmailTB.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(129, 317);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 20);
            this.label6.TabIndex = 10;
            this.label6.Text = "Email";
            // 
            // StudentNumberTB
            // 
            this.StudentNumberTB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.StudentNumberTB.Location = new System.Drawing.Point(274, 366);
            this.StudentNumberTB.Name = "StudentNumberTB";
            this.StudentNumberTB.Size = new System.Drawing.Size(120, 26);
            this.StudentNumberTB.TabIndex = 13;
            this.StudentNumberTB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.StudentNumberTB_KeyPress);
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(129, 366);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(122, 20);
            this.label7.TabIndex = 12;
            this.label7.Text = "StudentNumber";
            // 
            // save
            // 
            this.save.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.save.BackColor = System.Drawing.Color.MediumAquamarine;
            this.save.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.save.Location = new System.Drawing.Point(469, 259);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(96, 39);
            this.save.TabIndex = 14;
            this.save.Text = "Save";
            this.save.UseVisualStyleBackColor = false;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // home
            // 
            this.home.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.home.BackColor = System.Drawing.Color.MediumAquamarine;
            this.home.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.home.Location = new System.Drawing.Point(590, 259);
            this.home.Name = "home";
            this.home.Size = new System.Drawing.Size(96, 39);
            this.home.TabIndex = 15;
            this.home.Text = "Home";
            this.home.UseVisualStyleBackColor = false;
            this.home.Click += new System.EventHandler(this.home_Click);
            // 
            // StudentDataEntry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.home);
            this.Controls.Add(this.save);
            this.Controls.Add(this.StudentNumberTB);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.EmailTB);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.PhoneTB);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.AgeTB);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.CountryTB);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.AddressTB);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.NameTB);
            this.Controls.Add(this.label1);
            this.Name = "StudentDataEntry";
            this.Text = "StudentDataEntry";
            this.Load += new System.EventHandler(this.StudentDataEntry_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox NameTB;
        private System.Windows.Forms.TextBox AddressTB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox CountryTB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox AgeTB;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox PhoneTB;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox EmailTB;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox StudentNumberTB;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button save;
        private System.Windows.Forms.Button home;
    }
}